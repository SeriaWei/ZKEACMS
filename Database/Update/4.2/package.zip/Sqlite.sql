ALTER TABLE ArticleType ADD DisplayOrder int NULL;
ALTER TABLE ProductCategory ADD DisplayOrder int NULL;
ALTER TABLE VideoType ADD DisplayOrder int NULL;