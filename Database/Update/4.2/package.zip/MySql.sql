ALTER TABLE ArticleType ADD DisplayOrder INT NULL;
ALTER TABLE ProductCategory ADD DisplayOrder INT NULL;
ALTER TABLE VideoType ADD DisplayOrder INT NULL;