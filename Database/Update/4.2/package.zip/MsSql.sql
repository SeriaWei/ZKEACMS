ALTER TABLE dbo.ArticleType ADD DisplayOrder int NULL
GO
ALTER TABLE dbo.ProductCategory ADD DisplayOrder int NULL
GO
ALTER TABLE dbo.VideoType ADD DisplayOrder int NULL
GO