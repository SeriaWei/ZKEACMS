DELETE FROM [Language] WHERE LanKey = 'Captcha';
INSERT INTO [Language] (LanKey,CultureName,LanValue) values('Captcha','zh-CN','验证码');