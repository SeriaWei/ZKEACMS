DELETE FROM [Language] WHERE LanKey = N'Captcha';
INSERT INTO [Language] (LanKey,CultureName,LanValue) values(N'Captcha',N'zh-CN',N'验证码');