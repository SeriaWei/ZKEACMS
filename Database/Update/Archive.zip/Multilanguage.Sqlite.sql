﻿CREATE TABLE [Culture] (
  [CultureID] INTEGER NOT NULL
, [Domain] nvarchar(50) NULL
, [LCID] int NOT NULL
, [Title] nvarchar(50) NULL
, [CultureCode] nvarchar(20) NULL
, [EnglishName] nvarchar(100) NULL
, [DisplayName] nvarchar(100) NULL
, [UrlCode] nvarchar(10) NULL
, [Flag] nvarchar(200) NULL
, [Status] int NOT NULL
, [Description] nvarchar(200) NULL
, [CreateBy] nvarchar(50) NULL
, [CreateByName] nvarchar(100) NULL
, [CreateDate] datetime NULL
, [LastUpdateBy] nvarchar(50) NULL
, [LastUpdateByName] nvarchar(100) NULL
, [LastUpdateDate] datetime NULL
, CONSTRAINT [Culture_PK] PRIMARY KEY ([CultureID])
);
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey LIKE 'Culture@%';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey LIKE 'CultureSetting@%';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@CreatebyName', 'zh-CN', '创建人', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@CreateDate', 'zh-CN', '创建日期', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@CultureCode', 'zh-CN', '语言缩写', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@CultureID', 'zh-CN', 'CultureID', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@Description', 'zh-CN', '描述', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@DisplayName', 'zh-CN', '显示名称', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@Domain', 'zh-CN', '域名', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@EnglishName', 'zh-CN', '英文名', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@Flag', 'zh-CN', '旗帜', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@LastUpdateByName', 'zh-CN', '更新人', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@LastUpdateDate', 'zh-CN', '更新日期', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@LCID', 'zh-CN', 'LCID', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@Status', 'zh-CN', '状态', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@Title', 'zh-CN', '标题', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('Culture@UrlCode', 'zh-CN', 'Url缩写', 'Culture', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('CultureSetting@CultureMode', 'zh-CN', '多语言模式', 'CultureSetting', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('CultureSetting@DefaultCulture', 'zh-CN', '默认语言', 'CultureSetting', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('CultureSetting@IsEnable', 'zh-CN', '是否启用？', 'CultureSetting', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('CultureSetting@IsShowDefault', 'zh-CN', '无内容时使用默认语言？', 'CultureSetting', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ContentField@Title'; 
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ContentField@Name';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ContentField@FieldType';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentField@Title', 'zh-CN', '显示名称', 'ContentField', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentField@Name', 'zh-CN', '属性名', 'ContentField', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentField@FieldType', 'zh-CN', '字段类型', 'ContentField', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ContentTemplate@Template';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentTemplate@Template', 'zh-CN', '模板代码', 'ContentTemplate', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ContentType@Fields';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentType@Fields', 'zh-CN', '字段', 'ContentType', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'FluidContentWidget@ContentValueID';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'FluidContentWidget@ContentTemplateID';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'FluidContentWidget@IsSupportQueryID';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('FluidContentWidget@ContentValueID', 'zh-CN', '自定义内容', 'FluidContentWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('FluidContentWidget@ContentTemplateID', 'zh-CN', '显示模板', 'FluidContentWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('FluidContentWidget@IsSupportQueryID', 'zh-CN', '动态内容', 'FluidContentWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BiographyWidget@Name';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BiographyWidget@Photo'; 
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BiographyWidget@Others'; 
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BiographyWidget@Content'; 
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BiographyWidget@Name', 'zh-CN', '名称', 'BiographyWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BiographyWidget@Photo', 'zh-CN', '照片', 'BiographyWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BiographyWidget@Others', 'zh-CN', '其它', 'BiographyWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BiographyWidget@Content', 'zh-CN', '详细信息', 'BiographyWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'StrongPoint@Title';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'StrongPoint@Description';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StrongPoint@Title', 'zh-CN', '名称', 'StrongPoint', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StrongPoint@Description', 'zh-CN', '描述', 'StrongPoint', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@ApplicationKey';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@Height';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@LocationPoint';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@TagTitle';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@TagSummary';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'BaiduMapWidget@Instruction'; 
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@ApplicationKey', 'zh-CN', '服务密钥(AK)', 'BaiduMapWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@Height', 'zh-CN', '地图高度(px)', 'BaiduMapWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@LocationPoint', 'zh-CN', '位置坐标', 'BaiduMapWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@TagTitle', 'zh-CN', '标注', 'BaiduMapWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@TagSummary', 'zh-CN', '标注说明', 'BaiduMapWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('BaiduMapWidget@Instruction', 'zh-CN', '相关链接', 'BaiduMapWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'HistoryEventWidget@Events';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('HistoryEventWidget@Events', 'zh-CN', '历史事件', 'HistoryEventWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'HistoryEventItem@Title';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'HistoryEventItem@Description';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('HistoryEventItem@Title', 'zh-CN', '年份', 'HistoryEventItem', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('HistoryEventItem@Description', 'zh-CN', '事件', 'HistoryEventItem', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'ParallaxWidget@ImageUrl';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ParallaxWidget@ImageUrl', 'zh-CN', '图片', 'ParallaxWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'FluidContentListWidget@ContentTypeID';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'FluidContentListWidget@ContentTemplateID';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('FluidContentListWidget@ContentTypeID', 'zh-CN', '自定义内容类型', 'FluidContentListWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('FluidContentListWidget@ContentTemplateID', 'zh-CN', '显示模板', 'FluidContentListWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AuthOption@ClientId';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AuthOption@ClientSecret';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AuthOption@ClientId', 'zh-CN', 'APP ID', 'AuthOption', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AuthOption@ClientSecret', 'zh-CN', 'APP Key', 'AuthOption', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'OAuthWidget@Redirect';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'OAuthWidget@QQ';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'OAuthWidget@WeChat';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'OAuthWidget@WeiBo';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('OAuthWidget@Redirect', 'zh-CN', '跳转地址', 'OAuthWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('OAuthWidget@QQ', 'zh-CN', 'QQ?', 'OAuthWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('OAuthWidget@WeChat', 'zh-CN', '微信?', 'OAuthWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('OAuthWidget@WeiBo', 'zh-CN', '微博?', 'OAuthWidget', 'EntityProperty');

DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AlipayOptions@Uid';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AlipayOptions@Gatewayurl';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AlipayOptions@AlipayPublicKey';
DELETE From [Language] WHERE [CultureName]='zh-CN' AND LanKey = 'AlipayOptions@PrivateKey';
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AlipayOptions@Uid', 'zh-CN', '商户UID', 'AlipayOptions', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AlipayOptions@Gatewayurl', 'zh-CN', '支付宝网关', 'AlipayOptions', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AlipayOptions@AlipayPublicKey', 'zh-CN', '应用公钥', 'AlipayOptions', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('AlipayOptions@PrivateKey', 'zh-CN', '应用私钥', 'AlipayOptions', 'EntityProperty');

INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (1,NULL,2052,'中文(简体)','zh-CN','Chinese (Simplified, PRC)','中文(简体)','cn','~/images/culture-flags/zh-CN.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (2,NULL,1028,'中文(繁体)','zh-TW','Chinese (Traditional, Taiwan)','中文(繁體)','tw','~/images/culture-flags/zh-TW.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (3,NULL,1033,'英语 (美式)','en-US','English (United States)','English (US)','us','~/images/culture-flags/en-US.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (4,NULL,2057,'英语 (英式)','en-GB','English (United Kingdom)','English','en','~/images/culture-flags/en-GB.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (5,NULL,1046,'葡萄牙语 (巴西)','pt-BR','Portuguese (Brazil)','Português (Brasil)','br','~/images/culture-flags/pt-BR.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (6,NULL,1049,'俄语 (俄罗斯)','ru-RU','Russian (Russia)','Pycckий','ru','~/images/culture-flags/ru-RU.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (7,NULL,1041,'日本語','ja-JP','Japanese (Japan)','日本語','jp','~/images/culture-flags/ja-JP.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (8,NULL,1066,'越南语 (越南)','vi-VN','Vietnamese (Vietnam)','Tiếng Việt','vn','~/images/culture-flags/vi-VN.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (9,NULL,1036,'法语 (法国)','fr-FR','French (France)','Français','fr','~/images/culture-flags/fr-FR.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (10,NULL,1045,'波兰语 (波兰)','pl-PL','Polish (Poland)','Polski','pl','~/images/culture-flags/pl-PL.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (11,NULL,1040,'义大利语 (义大利)','it-IT','Italian (Italy)','Italiano','it','~/images/culture-flags/it-IT.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (12,NULL,1055,'土耳其语 (土耳其)','tr-TR','Turkish (Turkey)','Türkçe','tr','~/images/culture-flags/tr-TR.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (13,NULL,1042,'韩文 (韩国)','ko-KR','Korean (Korea)','한국어','kr','~/images/culture-flags/ko-KR.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (14,NULL,1054,'泰语 (泰国)','th-TH','Thai (Thailand)','ไทย','th','~/images/culture-flags/th-TH.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (15,NULL,1031,'德语 (德国)','de-DE','German (Germany)','Deutsch','de','~/images/culture-flags/de-DE.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (16,NULL,2058,'西班牙语 (墨西哥)','es-MX','Spanish (Mexico)','Español (Latam)','latam','~/images/culture-flags/es-MX.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (17,NULL,3082,'西班牙语 (西班牙，南美洲)','es-ES','Spanish (Spain, International Sort)','Español','es','~/images/culture-flags/es-ES.gif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (18,NULL,3073,'阿拉伯语 (阿拉伯语)','ar-EG','Arabic (Egypt)','Arabic (Egypt)','eg','~/images/culture-flags/ar-EG.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (19,NULL,1029,'捷克语 (捷克共和国)','cs-CZ','Czech (Czech Republic)','Czech (Czech Republic)','cz','~/images/culture-flags/cs-CZ.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (20,NULL,2055,'德语 (瑞士)','de-CH','German (Switzerland)','German (Switzerland)','ch','~/images/culture-flags/de-CH.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (21,NULL,1030,'丹麦语 (丹麦)','da-DK','Danish (Denmark)','Danish (Denmark)','dk','~/images/culture-flags/da-DK.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (22,NULL,1035,'芬兰语 (芬兰)','fi-FI','Finnish (Finland)','Finnish (Finland)','fi','~/images/culture-flags/fi-FI.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (23,NULL,1032,'希腊语 (希腊)','el-GR','Greek (Greece)','Greek (Greece)','gr','~/images/culture-flags/el-GR.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (24,NULL,1038,'匈牙利语 (匈牙利)','hu-HU','Hungarian (Hungary)','Hungarian (Hungary)','hu','~/images/culture-flags/hu-HU.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (25,NULL,1043,'荷兰语 (荷兰)','nl-NL','Dutch (Netherlands)','Dutch (Netherlands)','nl','~/images/culture-flags/nl-NL.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (26,NULL,2068,'挪威语 (挪威语)','nn-NO','Norwegian, Nynorsk (Norway)','Norwegian, Nynorsk (Norway)','no','~/images/culture-flags/nn-NO.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (27,NULL,1048,'罗马尼亚语 (罗马尼亚)','ro-RO','Romanian (Romania)','Romanian (Romania)','ro','~/images/culture-flags/ro-RO.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (28,NULL,1053,'瑞典语 (瑞典)','sv-SE','Swedish (Sweden)','Swedish (Sweden)','se','~/images/culture-flags/sv-SE.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (29,NULL,7177,'英语 (南非)','en-ZA','English (South Africa)','English (South Africa)','za','~/images/culture-flags/en-ZA.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (30,NULL,1057,'印度尼西亚语 (印度尼西亚)','id-ID','Indonesian (Indonesia)','Indonesian (Indonesia)','id','~/images/culture-flags/id-ID.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (31,NULL,3081,'英语 (澳大利亚)','en-AU','English (Australia)','English (Australia)','au','~/images/culture-flags/en-AU.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (32,NULL,2057,'英语 (欧洲中东非洲)','en-SG','English (EMEA)','English (EMEA)','emea','~/images/culture-flags/None.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (33,NULL,16393,'英语 (印度)','en-IN','English (India)','English (India)','in','~/images/culture-flags/en-IN.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [Culture] ([CultureID],[Domain],[LCID],[Title],[CultureCode],[EnglishName],[DisplayName],[UrlCode],[Flag],[Status],[Description],[CreateBy],[CreateByName],[CreateDate],[LastUpdateBy],[LastUpdateByName],[LastUpdateDate]) VALUES (34,NULL,2057,'英语 (亚太地区)','en-PH','English (APAC)','English (APAC)','apac','~/images/culture-flags/None.gif',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);


INSERT INTO DataDictionary( DicName ,Title ,DicValue ,[Order] ,Pid ,IsSystem, Status )
SELECT 'CultureSetting@CultureMode','单域名模式',1,1,0,1,0 UNION ALL
SELECT 'CultureSetting@CultureMode','独立域名模式',2,3,0,1,0;

ALTER TABLE CMS_Page ADD ContentID NVARCHAR(100);
ALTER TABLE CMS_Page ADD CultureID INT;
UPDATE CMS_Page SET ContentID = ID,CultureID = 1;

ALTER TABLE Navigation ADD ContentID NVARCHAR(100);
ALTER TABLE Navigation ADD CultureID INT;
UPDATE Navigation SET ContentID = ID,CultureID = 1;

ALTER TABLE Product ADD ContentID NVARCHAR(100);
ALTER TABLE Product ADD CultureID INT;
UPDATE Product SET ContentID = ID,CultureID = 1;

ALTER TABLE ProductCategory ADD ContentID NVARCHAR(100);
ALTER TABLE ProductCategory ADD CultureID INT;
UPDATE ProductCategory SET ContentID = ID,CultureID = 1;

ALTER TABLE Article ADD ContentID NVARCHAR(100);
ALTER TABLE Article ADD CultureID INT;
UPDATE Article SET ContentID = ID,CultureID = 1;

ALTER TABLE ArticleType ADD ContentID NVARCHAR(100);
ALTER TABLE ArticleType ADD CultureID INT;
UPDATE ArticleType SET ContentID = ID,CultureID = 1;

ALTER TABLE ProductCategoryTag ADD ContentID NVARCHAR(100);
ALTER TABLE ProductCategoryTag ADD CultureID INT;
UPDATE ProductCategoryTag SET ContentID = ID,CultureID = 1;

ALTER TABLE Forms ADD ContentID NVARCHAR(100);
ALTER TABLE Forms ADD CultureID INT;
UPDATE Forms SET ContentID = ID,CultureID = 1;

ALTER TABLE FluidContentValue ADD ContentID NVARCHAR(100);
ALTER TABLE FluidContentValue ADD CultureID INT;
UPDATE FluidContentValue SET ContentID = ID,CultureID = 1;

INSERT INTO Permission( PermissionKey,RoleId,Title,Module)
SELECT 'Culture_Manage',1,'多语言设置','设置';