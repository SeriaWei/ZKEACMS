﻿alter table Forms add Attribution int null
GO
update Forms set Attribution=1
GO
alter table ExtendField add PropertyName nvarchar(50) null

alter table ExtendField add ValueArray nvarchar(max) null
GO

INSERT INTO [Language]
( 
 [LanKey], [CultureName], [LanValue], [Module], [LanType]
)
VALUES
( 
 N'PageEntity@Scripts', N'zh-CN', N'脚本',N'PageEntity',N'EntityProperty'
),
( 
 N'PageEntity@Styles', N'zh-CN', N'样式',N'PageEntity',N'EntityProperty'
),
( 
 N'PageAsset@Url', N'zh-CN', N'Url',N'PageEntity',N'EntityProperty'
)
GO