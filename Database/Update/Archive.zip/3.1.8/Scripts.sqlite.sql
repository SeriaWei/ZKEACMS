﻿alter table Forms add Attribution int null;
update Forms set Attribution=1;
alter table ExtendField add PropertyName nvarchar(50) null;
alter table ExtendField add ValueArray ntext null;

INSERT INTO [Language]
( 
 [LanKey], [CultureName], [LanValue], [Module], [LanType]
)
VALUES
( 
 'PageEntity@Scripts', 'zh-CN', '脚本','PageEntity','EntityProperty'
),
( 
 'PageEntity@Styles', 'zh-CN', '样式','PageEntity','EntityProperty'
),
( 
 'PageAsset@Url', 'zh-CN', 'Url','PageEntity','EntityProperty'
)