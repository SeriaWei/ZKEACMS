﻿DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentField@Title'; 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'SplitviewWidget@Images'; 
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentField@Title', N'zh-CN', N'显示名称', N'ContentField', N'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SplitviewWidget@Images', N'zh-CN', N'图片', N'SplitviewWidget', N'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SiteSearchWidget@SearchEngine', N'zh-CN', N'搜索引擎', NULL, N'EntityProperty');