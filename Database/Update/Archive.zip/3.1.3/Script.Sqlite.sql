﻿DELETE From [Language] WHERE [CultureName] = 'zh-CN' AND LanKey = 'ContentField@Title'; 
DELETE From [Language] WHERE [CultureName] = 'zh-CN' AND LanKey = 'SplitviewWidget@Images'; 
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('ContentField@Title', 'zh-CN', '显示名称', 'ContentField', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('SplitviewWidget@Images', 'zh-CN', '图片', 'SplitviewWidget', 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('SiteSearchWidget@SearchEngine', 'zh-CN', '搜索引擎', NULL, 'EntityProperty');