﻿
DELETE FROM Language WHERE LanKey='Keywords@Url' AND CultureName='zh-CN';

INSERT INTO Language
(
    LanKey,
    CultureName,
    LanValue,
    Module,
    LanType
)
VALUES
(   'Keywords@Url',
    'zh-CN', 
    'Url', 
    'Keywords', 
    'EntityProperty'  
    )