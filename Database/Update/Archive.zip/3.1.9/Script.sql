﻿
DELETE dbo.Language WHERE LanKey=N'Keywords@Url' AND CultureName=N'zh-CN'

INSERT INTO dbo.Language
(
    LanKey,
    CultureName,
    LanValue,
    Module,
    LanType
)
VALUES
(   N'Keywords@Url',
    N'zh-CN', 
    N'Url', 
    N'Keywords', 
    N'EntityProperty'  
    )