﻿update Language set LanValue=N'英文名' where LanKey=N'ArticleEntity@Url' and CultureName=N'zh-CN';
update Language set LanValue=N'英文名' where LanKey=N'ArticleType@Url' and CultureName=N'zh-CN';
update Language set LanValue=N'英文名' where LanKey=N'ProductCategory@Url' and CultureName=N'zh-CN';
update Language set LanValue=N'英文名' where LanKey=N'ProductEntity@Url' and CultureName=N'zh-CN';

delete from [Language] where LanKey=N'ArticleSpecialDetailWidget@ArticleId';
delete from [Language] where LanKey=N'ArticleSpecialDetailWidget@ArticleName';
delete FROM [Language] where LanKey like N'TemplateFile@%';

insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('ArticleSpecialDetailWidget@ArticleId',N'zh-CN',N'文章ID',N'ArticleSpecialDetailWidget',N'EntityProperty');
insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('ArticleSpecialDetailWidget@ArticleName',N'zh-CN',N'文章英文名',N'ArticleSpecialDetailWidget',N'EntityProperty');

insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('TemplateFile@Content',N'zh-CN',N'模板代码',N'TemplateFile',N'EntityProperty');
insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('TemplateFile@LastUpdateTime',N'zh-CN',N'最后更新时间',N'TemplateFile',N'EntityProperty');
insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('TemplateFile@Name',N'zh-CN',N'名称',N'TemplateFile',N'EntityProperty');
insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('TemplateFile@RelativePath',N'zh-CN',N'模板路径',N'TemplateFile',N'EntityProperty');
insert into Language (LanKey,CultureName,LanValue,Module,LanType) VALUES('TemplateFile@ThemeName',N'zh-CN',N'主题',N'TemplateFile',N'EntityProperty');