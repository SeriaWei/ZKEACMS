ALTER TABLE [dbo].[CMS_Page]
    ADD [BodyStyle] NVARCHAR(MAX)
GO