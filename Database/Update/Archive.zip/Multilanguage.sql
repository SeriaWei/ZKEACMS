﻿SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Culture](
	[CultureID] [INT] IDENTITY(1,1) NOT NULL,
	[Domain] NVARCHAR(50),
	[LCID] [INT] NOT NULL,
	[Title] NVARCHAR(50) NULL,
	[CultureCode] [NVARCHAR](20) NULL,
	[EnglishName] [NVARCHAR](100) NULL,
	[DisplayName] [NVARCHAR](100) NULL,
	[UrlCode] [NVARCHAR](10) NULL,
	[Flag] [NVARCHAR](200) NULL,
	[Status] [INT] NOT NULL,
	[Description] [NVARCHAR](200) NULL,
	[CreateBy] NVARCHAR(50) NULL,
	[CreateByName] NVARCHAR(100) NULL,
	[CreateDate] [DATETIME] NULL,
	[LastUpdateBy] NVARCHAR(50) NULL,
	[LastUpdateByName] NVARCHAR(100) NULL,
	[LastUpdateDate] [DATETIME] NULL
 CONSTRAINT [Culture_PK] PRIMARY KEY CLUSTERED 
(
	[CultureID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO

CREATE UNIQUE NONCLUSTERED INDEX [Culture_AK1] ON [dbo].[Culture]
(
	[CultureCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey LIKE N'Culture@%' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey LIKE N'CultureSetting@%' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@CreatebyName', N'zh-CN', N'创建人', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@CreateDate', N'zh-CN', N'创建日期', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@CultureCode', N'zh-CN', N'语言缩写', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@CultureID', N'zh-CN', N'CultureID', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@Description', N'zh-CN', N'描述', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@DisplayName', N'zh-CN', N'显示名称', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@Domain', N'zh-CN', N'域名', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@EnglishName', N'zh-CN', N'英文名', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@Flag', N'zh-CN', N'旗帜', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@LastUpdateByName', N'zh-CN', N'更新人', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@LastUpdateDate', N'zh-CN', N'更新日期', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@LCID', N'zh-CN', N'LCID', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@Status', N'zh-CN', N'状态', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@Title', N'zh-CN', N'标题', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'Culture@UrlCode', N'zh-CN', N'Url缩写', N'Culture', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'CultureSetting@CultureMode', N'zh-CN', N'多语言模式', N'CultureSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'CultureSetting@DefaultCulture', N'zh-CN', N'默认语言', N'CultureSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'CultureSetting@IsEnable', N'zh-CN', N'是否启用？', N'CultureSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'CultureSetting@IsShowDefault', N'zh-CN', N'无内容时使用默认语言？', N'CultureSetting', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentField@Title' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentField@Name' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentField@FieldType' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentField@Title', N'zh-CN', N'显示名称', N'ContentField', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentField@Name', N'zh-CN', N'属性名', N'ContentField', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentField@FieldType', N'zh-CN', N'字段类型', N'ContentField', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentTemplate@Template' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentTemplate@Template', N'zh-CN', N'模板代码', N'ContentTemplate', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ContentType@Fields' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ContentType@Fields', N'zh-CN', N'字段', N'ContentType', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'FluidContentWidget@ContentValueID' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'FluidContentWidget@ContentTemplateID' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'FluidContentWidget@IsSupportQueryID' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'FluidContentWidget@ContentValueID', N'zh-CN', N'自定义内容', N'FluidContentWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'FluidContentWidget@ContentTemplateID', N'zh-CN', N'显示模板', N'FluidContentWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'FluidContentWidget@IsSupportQueryID', N'zh-CN', N'动态内容', N'FluidContentWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BiographyWidget@Name' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BiographyWidget@Photo' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BiographyWidget@Others' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BiographyWidget@Content' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BiographyWidget@Name', N'zh-CN', N'名称', N'BiographyWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BiographyWidget@Photo', N'zh-CN', N'照片', N'BiographyWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BiographyWidget@Others', N'zh-CN', N'其它', N'BiographyWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BiographyWidget@Content', N'zh-CN', N'详细信息', N'BiographyWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'StrongPoint@Title' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'StrongPoint@Description' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StrongPoint@Title', N'zh-CN', N'名称', N'StrongPoint', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StrongPoint@Description', N'zh-CN', N'描述', N'StrongPoint', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@ApplicationKey' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@Height' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@LocationPoint' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@TagTitle' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@TagSummary' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'BaiduMapWidget@Instruction' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@ApplicationKey', N'zh-CN', N'服务密钥(AK)', N'BaiduMapWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@Height', N'zh-CN', N'地图高度(px)', N'BaiduMapWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@LocationPoint', N'zh-CN', N'位置坐标', N'BaiduMapWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@TagTitle', N'zh-CN', N'标注', N'BaiduMapWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@TagSummary', N'zh-CN', N'标注说明', N'BaiduMapWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'BaiduMapWidget@Instruction', N'zh-CN', N'相关链接', N'BaiduMapWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'HistoryEventWidget@Events' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'HistoryEventWidget@Events', N'zh-CN', N'历史事件', N'HistoryEventWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'HistoryEventItem@Title' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'HistoryEventItem@Description' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'HistoryEventItem@Title', N'zh-CN', N'年份', N'HistoryEventItem', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'HistoryEventItem@Description', N'zh-CN', N'事件', N'HistoryEventItem', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'ParallaxWidget@ImageUrl' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'ParallaxWidget@ImageUrl', N'zh-CN', N'图片', N'ParallaxWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'FluidContentListWidget@ContentTypeID' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'FluidContentListWidget@ContentTemplateID' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'FluidContentListWidget@ContentTypeID', N'zh-CN', N'自定义内容类型', N'FluidContentListWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'FluidContentListWidget@ContentTemplateID', N'zh-CN', N'显示模板', N'FluidContentListWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AuthOption@ClientId' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AuthOption@ClientSecret' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AuthOption@ClientId', N'zh-CN', N'APP ID', N'AuthOption', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AuthOption@ClientSecret', N'zh-CN', N'APP Key', N'AuthOption', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'OAuthWidget@Redirect' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'OAuthWidget@QQ' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'OAuthWidget@WeChat' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'OAuthWidget@WeiBo' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'OAuthWidget@Redirect', N'zh-CN', N'跳转地址', N'OAuthWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'OAuthWidget@QQ', N'zh-CN', N'QQ?', N'OAuthWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'OAuthWidget@WeChat', N'zh-CN', N'微信?', N'OAuthWidget', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'OAuthWidget@WeiBo', N'zh-CN', N'微博?', N'OAuthWidget', N'EntityProperty')
GO
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AlipayOptions@Uid' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AlipayOptions@Gatewayurl' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AlipayOptions@AlipayPublicKey' 
DELETE From [Language] WHERE [CultureName]=N'zh-CN' AND LanKey = N'AlipayOptions@PrivateKey' 
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AlipayOptions@Uid', N'zh-CN', N'商户UID', N'AlipayOptions', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AlipayOptions@Gatewayurl', N'zh-CN', N'支付宝网关', N'AlipayOptions', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AlipayOptions@AlipayPublicKey', N'zh-CN', N'应用公钥', N'AlipayOptions', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'AlipayOptions@PrivateKey', N'zh-CN', N'应用私钥', N'AlipayOptions', N'EntityProperty')
GO

SET IDENTITY_INSERT [dbo].[Culture] ON 
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (1, NULL, 2052, N'zh-CN', N'Chinese (Simplified, PRC)', N'中文(简体)', N'cn', N'~/images/culture-flags/zh-CN.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'中文(简体)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (2, NULL, 1028, N'zh-TW', N'Chinese (Traditional, Taiwan)', N'中文(繁體)', N'tw', N'~/images/culture-flags/zh-TW.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'中文(繁体)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (3, NULL, 1033, N'en-US', N'English (United States)', N'English (US)', N'us', N'~/images/culture-flags/en-US.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (美式)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (4, NULL, 2057, N'en-GB', N'English (United Kingdom)', N'English', N'en', N'~/images/culture-flags/en-GB.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (英式)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (5, NULL, 1046, N'pt-BR', N'Portuguese (Brazil)', N'Português (Brasil)', N'br', N'~/images/culture-flags/pt-BR.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'葡萄牙语 (巴西)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (6, NULL, 1049, N'ru-RU', N'Russian (Russia)', N'Pycckий', N'ru', N'~/images/culture-flags/ru-RU.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'俄语 (俄罗斯)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (7, NULL, 1041, N'ja-JP', N'Japanese (Japan)', N'日本語', N'jp', N'~/images/culture-flags/ja-JP.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'日本語')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (8, NULL, 1066, N'vi-VN', N'Vietnamese (Vietnam)', N'Tiếng Việt', N'vn', N'~/images/culture-flags/vi-VN.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'越南语 (越南)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (9, NULL, 1036, N'fr-FR', N'French (France)', N'Français', N'fr', N'~/images/culture-flags/fr-FR.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'法语 (法国)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (10, NULL, 1045, N'pl-PL', N'Polish (Poland)', N'Polski', N'pl', N'~/images/culture-flags/pl-PL.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'波兰语 (波兰)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (11, NULL, 1040, N'it-IT', N'Italian (Italy)', N'Italiano', N'it', N'~/images/culture-flags/it-IT.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'义大利语 (义大利)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (12, NULL, 1055, N'tr-TR', N'Turkish (Turkey)', N'Türkçe', N'tr', N'~/images/culture-flags/tr-TR.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'土耳其语 (土耳其)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (13, NULL, 1042, N'ko-KR', N'Korean (Korea)', N'한국어', N'kr', N'~/images/culture-flags/ko-KR.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'韩文 (韩国)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (14, NULL, 1054, N'th-TH', N'Thai (Thailand)', N'ไทย', N'th', N'~/images/culture-flags/th-TH.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'泰语 (泰国)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (15, NULL, 1031, N'de-DE', N'German (Germany)', N'Deutsch', N'de', N'~/images/culture-flags/de-DE.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'德语 (德国)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (16, NULL, 2058, N'es-MX', N'Spanish (Mexico)', N'Español (Latam)', N'latam', N'~/images/culture-flags/es-MX.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'西班牙语 (墨西哥)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (17, NULL, 3082, N'es-ES', N'Spanish (Spain, International Sort)', N'Español', N'es', N'~/images/culture-flags/es-ES.gif', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'西班牙语 (西班牙，南美洲)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (18, NULL, 3073, N'ar-EG', N'Arabic (Egypt)', N'Arabic (Egypt)', N'eg', N'~/images/culture-flags/ar-EG.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'阿拉伯语 (阿拉伯语)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (19, NULL, 1029, N'cs-CZ', N'Czech (Czech Republic)', N'Czech (Czech Republic)', N'cz', N'~/images/culture-flags/cs-CZ.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'捷克语 (捷克共和国)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (20, NULL, 2055, N'de-CH', N'German (Switzerland)', N'German (Switzerland)', N'ch', N'~/images/culture-flags/de-CH.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'德语 (瑞士)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (21, NULL, 1030, N'da-DK', N'Danish (Denmark)', N'Danish (Denmark)', N'dk', N'~/images/culture-flags/da-DK.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'丹麦语 (丹麦)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (22, NULL, 1035, N'fi-FI', N'Finnish (Finland)', N'Finnish (Finland)', N'fi', N'~/images/culture-flags/fi-FI.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'芬兰语 (芬兰)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (23, NULL, 1032, N'el-GR', N'Greek (Greece)', N'Greek (Greece)', N'gr', N'~/images/culture-flags/el-GR.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'希腊语 (希腊)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (24, NULL, 1038, N'hu-HU', N'Hungarian (Hungary)', N'Hungarian (Hungary)', N'hu', N'~/images/culture-flags/hu-HU.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'匈牙利语 (匈牙利)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (25, NULL, 1043, N'nl-NL', N'Dutch (Netherlands)', N'Dutch (Netherlands)', N'nl', N'~/images/culture-flags/nl-NL.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'荷兰语 (荷兰)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (26, NULL, 2068, N'nn-NO', N'Norwegian, Nynorsk (Norway)', N'Norwegian, Nynorsk (Norway)', N'no', N'~/images/culture-flags/nn-NO.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'挪威语 (挪威语)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (27, NULL, 1048, N'ro-RO', N'Romanian (Romania)', N'Romanian (Romania)', N'ro', N'~/images/culture-flags/ro-RO.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'罗马尼亚语 (罗马尼亚)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (28, NULL, 1053, N'sv-SE', N'Swedish (Sweden)', N'Swedish (Sweden)', N'se', N'~/images/culture-flags/sv-SE.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'瑞典语 (瑞典)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (29, NULL, 7177, N'en-ZA', N'English (South Africa)', N'English (South Africa)', N'za', N'~/images/culture-flags/en-ZA.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (南非)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (30, NULL, 1057, N'id-ID', N'Indonesian (Indonesia)', N'Indonesian (Indonesia)', N'id', N'~/images/culture-flags/id-ID.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'印度尼西亚语 (印度尼西亚)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (31, NULL, 3081, N'en-AU', N'English (Australia)', N'English (Australia)', N'au', N'~/images/culture-flags/en-AU.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (澳大利亚)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (32, NULL, 2057, N'en-SG', N'English (EMEA)', N'English (EMEA)', N'emea', N'~/images/culture-flags/None.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (欧洲中东非洲)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (33, NULL, 16393, N'en-IN', N'English (India)', N'English (India)', N'in', N'~/images/culture-flags/en-IN.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (印度)')
INSERT [dbo].[Culture] ([CultureID], [Domain], [LCID], [CultureCode], [EnglishName], [DisplayName], [UrlCode], [Flag], [Status], [Description], [CreateBy], [CreateByName], [CreateDate], [LastUpdateBy], [LastUpdateByName], [LastUpdateDate], [Title]) VALUES (34, NULL, 2057, N'en-PH', N'English (APAC)', N'English (APAC)', N'apac', N'~/images/culture-flags/None.gif', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'英语 (亚太地区)')
SET IDENTITY_INSERT [dbo].[Culture] OFF

GO

INSERT INTO dbo.DataDictionary( DicName ,Title ,DicValue ,[Order] ,Pid ,IsSystem, Status )
SELECT N'CultureSetting@CultureMode',N'单域名模式',1,1,0,1,0 UNION ALL
SELECT N'CultureSetting@CultureMode',N'独立域名模式',2,3,0,1,0
GO

ALTER TABLE dbo.CMS_Page ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.CMS_Page ADD CultureID INT
GO
UPDATE cms_page SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.Navigation ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.Navigation ADD CultureID INT
GO
UPDATE dbo.Navigation SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.Product ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.Product ADD CultureID INT
GO
UPDATE dbo.Product SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.ProductCategory ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.ProductCategory ADD CultureID INT
GO
UPDATE dbo.ProductCategory SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.Article ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.Article ADD CultureID INT
GO
UPDATE dbo.Article SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.ArticleType ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.ArticleType ADD CultureID INT
GO
UPDATE dbo.ArticleType SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.ProductCategoryTag ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.ProductCategoryTag ADD CultureID INT
GO
UPDATE dbo.ProductCategoryTag SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.Forms ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.Forms ADD CultureID INT
GO
UPDATE dbo.Forms SET ContentID = ID,CultureID = 1
GO
ALTER TABLE dbo.FluidContentValue ADD ContentID NVARCHAR(100)
ALTER TABLE dbo.FluidContentValue ADD CultureID INT
GO
UPDATE dbo.FluidContentValue SET ContentID = ID,CultureID = 1
GO
INSERT INTO dbo.Permission( PermissionKey,RoleId,Title,Module)
SELECT N'Culture_Manage',1,N'多语言设置',N'设置' 