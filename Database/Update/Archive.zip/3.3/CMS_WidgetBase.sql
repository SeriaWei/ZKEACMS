﻿update CMS_WidgetBase set Description=N'Image Text' where Description=N'图片文字' and IsTemplate=1
update CMS_WidgetBase set Description=N'Text Title' where Description=N'文字标题' and IsTemplate=1
update CMS_WidgetBase set Description=N'Other' where Description=N'其它' and IsTemplate=1