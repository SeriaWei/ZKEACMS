INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('TabWidget@TabItems', 'zh-CN', '标签项', 'TabWidget', 'EntityProperty')
