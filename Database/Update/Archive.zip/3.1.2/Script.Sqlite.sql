﻿ALTER TABLE ArticleType ADD SEOTitle NVARCHAR(100);
ALTER TABLE ArticleType ADD SEOKeyWord NVARCHAR(100);
ALTER TABLE ArticleType ADD SEODescription NVARCHAR(300);

ALTER TABLE ProductCategory ADD SEOTitle NVARCHAR(100);
ALTER TABLE ProductCategory ADD SEOKeyWord NVARCHAR(100);
ALTER TABLE ProductCategory ADD SEODescription NVARCHAR(300);

ALTER TABLE CMS_WidgetBase ADD InnerStyle NTEXT;

INSERT INTO DataDictionary( DicName ,Title ,DicValue ,[Order] ,Pid ,IsSystem, Status )
SELECT 'StaticPageSetting@CacheProvider','内存缓存','MemoryCache',1,0,1,0 UNION ALL
SELECT 'StaticPageSetting@CacheProvider','数据库缓存','Database',2,0,1,0 UNION ALL
SELECT 'StaticPageSetting@CacheProvider','文件缓存','File',3,0,1,0;

INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StaticPageSetting@CacheMinutes', 'zh-CN', '缓存时间（分钟）', NULL, 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StaticPageSetting@CacheProvider', 'zh-CN', '缓存方式', NULL, 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StaticPageSetting@Enable', 'zh-CN', '启用？', NULL, 'EntityProperty');
INSERT INTO [Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES ('StaticPageSetting@ExcludePages', 'zh-CN', '例外页面', NULL, 'EntityProperty');