﻿ALTER TABLE dbo.ArticleType ADD [SEOTitle] NVARCHAR(100) NULL
ALTER TABLE dbo.ArticleType ADD [SEOKeyWord] NVARCHAR(100) NULL
ALTER TABLE dbo.ArticleType ADD [SEODescription] NVARCHAR(300) NULL

ALTER TABLE dbo.ProductCategory ADD [SEOTitle] NVARCHAR(100) NULL
ALTER TABLE dbo.ProductCategory ADD [SEOKeyWord] NVARCHAR(100) NULL
ALTER TABLE dbo.ProductCategory ADD [SEODescription] NVARCHAR(300) NULL

ALTER TABLE dbo.CMS_WidgetBase ADD [InnerStyle] NVARCHAR(MAX) NULL
GO
INSERT INTO dbo.DataDictionary( DicName ,Title ,DicValue ,[Order] ,Pid ,IsSystem, Status )
SELECT N'StaticPageSetting@CacheProvider',N'内存缓存',N'MemoryCache',1,0,1,0 UNION ALL
SELECT N'StaticPageSetting@CacheProvider',N'数据库缓存',N'Database',2,0,1,0 UNION ALL
SELECT N'StaticPageSetting@CacheProvider',N'文件缓存',N'File',3,0,1,0
GO
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StaticPageSetting@CacheMinutes', N'zh-CN', N'缓存时间（分钟）', NULL, N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StaticPageSetting@CacheProvider', N'zh-CN', N'缓存方式', NULL, N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StaticPageSetting@Enable', N'zh-CN', N'启用？', NULL, N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'StaticPageSetting@ExcludePages', N'zh-CN', N'例外页面', NULL, N'EntityProperty')
