﻿using Easy.MetaData;
using Easy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZKEACMS.Standard.Models
{
    public class Standard : EditorEntity
    {
    }
    class StandardMetaData : ViewMetaData<Standard>
    {
        protected override void ViewConfigure()
        {
            throw new NotImplementedException();
        }
    }
}
