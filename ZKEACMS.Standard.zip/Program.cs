﻿/*!
 * http://www.zkea.net/
 * Copyright 2017 ZKEASOFT
 * http://www.zkea.net/licenses
 */

namespace ZKEACMS.Standard
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
