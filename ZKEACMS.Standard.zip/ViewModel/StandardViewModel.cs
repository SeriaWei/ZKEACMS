﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZKEACMS.Standard.ViewModel
{
    public class StandardViewModel
    {
    }
}
