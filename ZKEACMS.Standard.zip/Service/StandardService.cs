﻿using Easy.RepositoryPattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZKEACMS.Standard.Models;
using Easy;

namespace ZKEACMS.Standard.Service
{
    public class StandardService : ServiceBase<Models.Standard>, IStandardService
    {
        public StandardService(IApplicationContext applicationContext, StandardDbContext dbContext) : base(applicationContext, dbContext)
        {
        }

        public override DbSet<Models.Standard> CurrentDbSet => (DbContext as StandardDbContext).Standard;
    }
}
