INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'TabWidget@TabItems', N'zh-CN', N'标签项', N'TabWidget', N'EntityProperty')
