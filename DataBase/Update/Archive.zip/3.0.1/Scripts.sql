INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SmtpSetting@Email', N'zh-CN', N'����', N'SmtpSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SmtpSetting@EnableSsl', N'zh-CN', N'����SSL', N'SmtpSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SmtpSetting@Host', N'zh-CN', N'������', N'SmtpSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SmtpSetting@PassWord', N'zh-CN', N'����', N'SmtpSetting', N'EntityProperty')
INSERT [dbo].[Language] ([LanKey], [CultureName], [LanValue], [Module], [LanType]) VALUES (N'SmtpSetting@Port', N'zh-CN', N'�˿�', N'SmtpSetting', N'EntityProperty')
GO